/*
-- Query: select * from role_has_permissions where role_id = 1
LIMIT 0, 50000

-- Date: 2024-01-10 13:08
*/
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (4,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (9,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (10,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (11,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (12,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (13,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (14,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (15,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (16,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (17,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (18,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (19,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (20,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (21,1);
INSERT INTO role_has_permissions (`permission_id`,`role_id`) VALUES (22,1);

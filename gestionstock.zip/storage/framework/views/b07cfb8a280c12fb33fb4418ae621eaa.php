<?php $__env->startSection('contentDashboard'); ?>

    <h3 class="rounded-2 p-2 bg-light">Fiche Client <?php echo e($clients->client); ?></h3>
    <form action="<?php echo e(url('getByCompanie')); ?>" method="get">
    <label for=""> Companige</label>

    <select name="idCompa" id="" class="form-control d-inline">
        <?php $__currentLoopData = $AllCompangie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <input type="text" name="id"  value="<?php echo e($idclient); ?>" hidden>
    <button type="submit" class="btn btn-secondary d-inline mt-5">search</button>
</form>

        
            <form action="<?php echo e(url('getByCompanie')); ?>" method="get">
                <div class="col-sm-12 col-md-6 col-xl-6">

                </div>
                <div class="col-sm-12 col-md-6 col-xl-6">

                </div>


        </div>


    



    <table class="table table-striped table-bordered w-100" id="tableFiche" data-page-lenght="-1">
        <thead>
            <tr>
                <th rowspan="2">Date</th>
                <th rowspan="2" style="background-color: rgb(248, 154, 154)">Sortie de caisses vides</th>
                <th colspan="<?php echo e($NumberColSpanEntre); ?>" style="background-color: rgb(174, 245, 174)">Entré de marchandises</th>
                <th colspan="<?php echo e($NumberColSpanSortie); ?>" style="background-color: rgb(114, 235, 205)">Sortie de marchandises</th>
                <th rowspan="2" style="background-color: rgb(247, 211, 211)">Retour de caisses vides</th>
            </tr>
            <tr>
                <?php if(!empty($uniqueProductsEntree)): ?>
                    <?php $__currentLoopData = $uniqueProductsEntree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="background-color: rgb(174, 245, 174)"><?php echo e($item); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <th style="background-color: rgb(174, 245, 174)"></th>
                <?php endif; ?>

                <?php if(!empty($uniqueProductsSortie)): ?>
                    <?php $__currentLoopData = $uniqueProductsSortie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th style="background-color: rgb(114, 235, 205)"><?php echo e($item); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <th style="background-color: rgb(114, 235, 205)"></th>
                <?php endif; ?>



            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(\Carbon\Carbon::parse($date)->format('d-m-Y')); ?></td>
                    <td style="background-color: rgb(248, 154, 154)"><?php echo e(intval($data['caisseVide'] ?? 0)); ?></td>

                    <!-- Check if uniqueProductsEntree is not empty -->
                    <?php if(!empty($uniqueProductsEntree)): ?>
                        <!-- Iterate over uniqueProductsEntree -->
                        <?php $__currentLoopData = $uniqueProductsEntree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="background-color: rgb(174, 245, 174)"><?php echo e(intval($data['marchandiseEntree'][$product] ?? 0)); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <td colspan="<?php echo e(count($uniqueProductsEntree)); ?>" style="background-color: rgb(174, 245, 174)">0</td>
                    <?php endif; ?>

                    <!-- Iterate over uniqueProductsSortie -->
                    <?php if(!empty($uniqueProductsSortie)): ?>
                        <?php $__currentLoopData = $uniqueProductsSortie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="background-color: rgb(114, 235, 205)"><?php echo e(intval($data['marchandiseSortie'][$product] ?? 0)); ?></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <!-- If uniqueProductsSortie is empty, display 0 in each column -->
                        <td colspan="<?php echo e(count($uniqueProductsSortie)); ?>" style="background-color: rgb(114, 235, 205)">0</td>
                    <?php endif; ?>

                    <td style="background-color: rgb(247, 211, 211)"><?php echo e(intval($data['caisseRetour'] ?? 0)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </tbody>
        <tfoot>
            <tr>
                <td>Total</td>
                <td style="background-color: rgb(248, 154, 154)"></td>
                <?php if(!empty($uniqueProductsEntree)): ?>
                    <?php $__currentLoopData = $uniqueProductsEntree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="background-color: rgb(174, 245, 174)"><?php echo e($totalss['entree'][$product] ?? 0); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <td style="background-color: rgb(174, 245, 174)"></td>
                <?php endif; ?>

                <?php if(!empty($uniqueProductsSortie)): ?>
                    <?php $__currentLoopData = $uniqueProductsSortie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td style="background-color: rgb(114, 235, 205)"><?php echo e($totalss['sortie'][$product] ?? 0); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <td style="background-color: rgb(114, 235, 205)"></td>
                <?php endif; ?>


                <td style="background-color: rgb(247, 211, 211)"></td>
            </tr>
            <tr>
                <th>Total Final</th>
                <th style="background-color: rgb(248, 154, 154)"><?php echo e($totalss['caisseVide']); ?></th>

                <?php
                    $totalEntree = array_sum($totalss['entree']);
                    $totalSortie = array_sum($totalss['sortie']);
                ?>

                <th colspan="<?php echo e($NumberColSpanEntre); ?>" style="text-align: center;background-color: rgb(174, 245, 174)"><?php echo e($totalEntree); ?></th>
                <th colspan="<?php echo e($NumberColSpanSortie); ?>" style="text-align: center ;background-color: rgb(114, 235, 205)"><?php echo e($totalSortie); ?></th>
                <th style="background-color: rgb(247, 211, 211)"><?php echo e($totalss['caisseRetour']); ?></th>
            </tr>
        </tfoot>

    </table>


    <div class="p-2 bg-light border mt-3">
        <p class=" fs-3"> restant caisses vides chez client    = <span><?php echo e($reste); ?></span></p>
        <p class="fs-3">resatant marachandise en stock= <span><?php echo e($resteMarchandise); ?></span></p>
    </div>



    <script>
        $(document).ready(function ()
        {

            $('#tableFiche').DataTable({
                "ordering": false,
                dom: 'Bfrtip',
                buttons: [
                    'excel'
                ],
                paging: false,
                "pageLength": -1,

                "select": {
                    "style": "single"
                },
                "language":
                {
                    "sInfo": "Affichage de l'élément _START_ à _END_ sur _TOTAL_ éléments",
                    "sInfoEmpty": "Affichage de l'élément 0 à 0 sur 0 élément",
                    "sInfoFiltered": "(filtré à partir de _MAX_ éléments au total)",
                    "sInfoPostFix": "",
                    "sInfoThousands": ",",
                    "sLengthMenu": "Afficher _MENU_ éléments",
                    "sLoadingRecords": "Chargement...",
                    "sProcessing": "Traitement...",
                    "sSearch": "Rechercher :",
                    "sZeroRecords": "Aucun élément correspondant trouvé",
                    "oPaginate": {
                        "sFirst": "Premier",
                        "sLast": "Dernier",
                        "sNext": "Suivant",
                        "sPrevious": "Précédent"
                    },
                    "oAria": {
                        "sSortAscending": ": activer pour trier la colonne par ordre croissant",
                        "sSortDescending": ": activer pour trier la colonne par ordre décroissant"
                    },
                    "select": {
                        "rows": {
                        "_": "%d lignes sélectionnées",
                        "0": "Aucune ligne sélectionnée",
                        "1": "1 ligne sélectionnée"
                        }
                    }
                },
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestionstock\resources\views/Dashboard/StiuationStock/FicheClient.blade.php ENDPATH**/ ?>
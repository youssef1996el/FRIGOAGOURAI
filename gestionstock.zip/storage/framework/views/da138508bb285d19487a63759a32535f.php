<?php $__env->startSection('contentDashboard'); ?>

<div class="row">

    <div class="col-lg-12 margin-tb">

        <div class="pull-left">

            <h2>Gestion des pourvoirs</h2>

        </div>

        <div class="pull-right">
            <a class="btn btn-success" href="<?php echo e(route('roles.create')); ?>">Ajouter pourvoir</a>
       

    </div>

</div>


<?php if($message = Session::get('success')): ?>

    <div class="alert alert-success">

        <p><?php echo e($message); ?></p>

    </div>

<?php endif; ?>


<table class="table table-bordered mt-3">

  <tr>

     <th>Numéro</th>

     <th>nom complet</th>

     <th width="280px">Action</th>

  </tr>

    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>

        <td><?php echo e(++$i); ?></td>

        <td><?php echo e($role->name); ?></td>

        <td>

            <a class="btn btn-info" href="<?php echo e(route('roles.show',$role->id)); ?>">Voir</a>

           

                <a class="btn btn-primary" href="<?php echo e(route('roles.edit',$role->id)); ?>">Modifier</a>

          

          

                <?php echo Form::open(['method' => 'DELETE','route' => ['roles.destroy', $role->id],'style'=>'display:inline']); ?>


                    <?php echo Form::submit('Suprimer', ['class' => 'btn btn-danger']); ?>


                <?php echo Form::close(); ?>


          

        </td>

    </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>


<?php echo $roles->render(); ?>


<script>
    $(document).ready(function () {
        var currentPath = window.location.pathname;
        var pathSegments = currentPath.split('/');
        var lastSegment = pathSegments[pathSegments.length - 1];
        if(lastSegment === "roles")
        {
            $('.list-unstyled li:has(span:contains("Pouvoirs utilisateurs"))').css({
                'background-color': 'rgb(159 226 212)',
                'box-shadow' :'5px 5px 10px #888888',
                'border-top-right-radius': '10px',
                'border-bottom-right-radius': '10px'
            }).find('i[data-feather="users"]').addClass('text-white');
        }
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\gestionstock\resources\views/roles/index.blade.php ENDPATH**/ ?>